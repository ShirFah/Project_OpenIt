<?php
	include("classes/conect.php");
    include("classes/login.php");
	include("classes/user.php");
	include("classes/posts.php");
	include("classes/Image.php");	
	include("classes/Profile.php");